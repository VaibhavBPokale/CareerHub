/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*/*.{html,css,ejs}"],
  theme: {
    extend: {},
  },
  plugins: [],
}